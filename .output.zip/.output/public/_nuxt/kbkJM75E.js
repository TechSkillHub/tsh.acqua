import{v as n,z as e}from"./3Mq18kNF.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
